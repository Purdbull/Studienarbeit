#include "Arduino.h"
#include "State.h"

State::State(){
}

void State::handle(){}


